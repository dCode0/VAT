his is a VAT Number Checker Web Application built with Reactjs with Redux. Users can input VAT Number, App checks validity of the inputted VAT number and returns VAT details.

Open https://vatlookup-app.herokuapp.com/ to view it in the browser.

Available Scripts
In the project directory, you can run:

npm start
Runs the app in the development mode.

npm run build
Builds the app for production to the build folder.
It correctly bundles React in production mode and optimizes the build for the best performance.

npm run dev
Installs all the node- modules and dependencies

npm test
Runs test




