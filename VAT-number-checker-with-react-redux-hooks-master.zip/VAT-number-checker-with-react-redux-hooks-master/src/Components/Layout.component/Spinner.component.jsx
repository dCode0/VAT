import React from "react";
import spinner from "./Spinner.gif";

//Spinner keeps my sanity
export default function Spinner() {
  return <img src={spinner} alt="loading..." />;
}
