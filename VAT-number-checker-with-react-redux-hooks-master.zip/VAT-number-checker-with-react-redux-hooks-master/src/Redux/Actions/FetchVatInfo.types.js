//to keep values constant

const FetchActionTypes = {
  FETCH_VAT_REQUEST: "FETCH_VAT_REQUEST",
  FETCH_VAT_SUCCESS: "FETCH_VAT_SUCCESS",
  FETCH_VAT_FAILURE: "FETCH_VAT_FAILURE"
};

export default FetchActionTypes;
